package com.example.whattoeat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ImageView image_cabbage = findViewById(R.id.imageView_cabbage);
        image_cabbage.setOnClickListener(v -> {
            Intent intent2 = new Intent(getApplicationContext(),Cabbage.class);
            startActivity(intent2);
        });

        ImageView image_radish = findViewById(R.id.imageView_radish);
        image_radish.setOnClickListener(v -> {
            Intent intent3 = new Intent(getApplicationContext(), Radish.class);
            startActivity(intent3);
        });

        ImageView image_onion = findViewById(R.id.imageView_onion);
        image_onion.setOnClickListener(v -> {
            Intent intent4 = new Intent(getApplicationContext(),Onion.class);
            startActivity(intent4);
        });

        ImageView image_garlic = findViewById(R.id.imageView_garlic);
        image_garlic.setOnClickListener(v -> {
            Intent intent5 = new Intent(getApplicationContext(),Garlic.class);
            startActivity(intent5);
        });

        ImageView image_pepper = findViewById(R.id.imageView_pepper);
        image_pepper.setOnClickListener(v -> {
            Intent intent6 = new Intent(getApplicationContext(),Pepper.class);
            startActivity(intent6);
        });

    }



}