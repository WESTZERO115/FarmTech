package com.example.whattoeat;

public class UI {
}
